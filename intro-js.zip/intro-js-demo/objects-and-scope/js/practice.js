// practice making objects in the console

//Use Object Constructor and Prototype to 
//create an animal object with a name, a key, and 
//the ability to move
// 

//Create a game object with the number of animals (players)
//and a win method


//Create a view object that can display a moved animal
//create the initial game board


//Experiment with scope - when events are added to objects you 
//need to bind them. 



