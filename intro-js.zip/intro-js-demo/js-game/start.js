//create a cat and a dog object with 
//name and position properties
//the initial value of position is 0


//create an advance function that takes an
//animal (cat or dog) and a moveAmount
//and changes the animal postion by move amount


//create a checkWinner function that checks the position of 
//both animals and returns the animal who's position
//is more than 20, and null otherwise


//Create a function display to display 
//that is passed a winner and creates an alert with the winner's name


//Create the play function with
//a loop that calls calls advance on each animal with a random number for moveAmoutn
//until one wins and then 
//calls the display fucntion to show the winner 

//Hint: you will need to research how to get a random number in JS


//run the game in the console by calling the play method.

//play()

//Bonus once you get the game working - refactor: 
// 1. create an array of animals [cat,dog] instead of separate objects.
// 2. refactor advance and winner so they still work
// 3. add a new animal to your array - does the game work now? 