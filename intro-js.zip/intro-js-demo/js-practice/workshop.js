// Practice basic JS

//Create variables and compare them

//Create arrays and access their elements

//Create objects and access their properties

//Make a contidional stament

//Make a do - while loop

//Make a for loop

//Define and call a function

//SOLUTIONS BELOW:  Copy into console to run

// var name="Bob";
// var greeting ="Hello";
// var age =35;
// var height = 70.5;

// age > height;
// height += 1;
// greeting = greeting + "! My name is " + name;

// var letters=["a", "b","c"];
// letters.push("a");
// letters.pop();
// letters[1];

// if (player.score > 30){
//   alert(player.name + " wins! ")
// }

// var password="secretWord";
// do{
//   input = prompt("Please enter your password");
// }
// while(input !== password)

// var scores=[2,34,15, 12];
// var sum=0;
// var len = scores.length;
// for(var counter=0; counter <= len; ++counter){
//   sum += scores[counter];
// }

// var greeting=function(username){
//   var sayHi="Hi there, " + name;
//   return sayHi;
// }

// var myName="Anne"
// var myGreeting = greeting(myName)
