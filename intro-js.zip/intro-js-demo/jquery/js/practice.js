//Read through the jQuery Documentation http://api.jquery.com/category/selectors/


$(document).ready(function(){
  // Any code within this function will run as soon as your page has loaded.

  //Practice Selecting elements on the page
    //H1, table row, .active table cell

  //Practice modifying the HTMl and CSS of elements on the page
    //Make the title say Elephants
    //Change the active cells to green
    //Change only the first active cell color

  //Practice responding to the click event    

});


//SOLUTIONS BELOW

//$("h1")
//$(".active")
//$(tr).first()

//$("h1").first().html("Elephants")
//$(".active").css({"background":"green"})
//$(".active").first().css({"background","pink"})


// $("td").on("click", function(){
//   console.log('clicked');
// })
