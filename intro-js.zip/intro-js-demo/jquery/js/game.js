//Be sure to include this file, not practice in your index.html file
$(document).ready(function(){

//Make your Cat and Dog game work in the browser by doing the following:
  // The game starts with no active cells
  // When “c” is pressed the cat moves and the first cell in the Cat Row is active.
  // When “d” is pressed the dog moves.
  // When either the cat or dog reaches the end, the game is over and a winner is announced.

});
